package com.ecocultura.florida;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.io.File;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class GallerypreviewActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private boolean showDetails = false;
	private HashMap<String, Object> dataMap = new HashMap<>();
	private String f_id = "";
	private String f_url = "";
	
	private LinearLayout main;
	private CardView boxHeader;
	private LinearLayout boxdetails;
	private ImageView image;
	private LinearLayout linear2;
	private LinearLayout btnBack;
	private TextView textview1;
	private LinearLayout BtnInformation;
	private ImageView imageview2;
	private ImageView imageview4;
	private TextView textview2;
	private TextView name;
	private TextView textview4;
	private TextView timestamp;
	private LinearLayout btnDelete;
	private ImageView imageview5;
	private TextView textview6;
	
	private AlertDialog.Builder d;
	private ProgressDialog pd;
	private StorageReference fsgalleries = _firebase_storage.getReference("galleries");
	private OnCompleteListener<Uri> _fsgalleries_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fsgalleries_download_success_listener;
	private OnSuccessListener _fsgalleries_delete_success_listener;
	private OnProgressListener _fsgalleries_upload_progress_listener;
	private OnProgressListener _fsgalleries_download_progress_listener;
	private OnFailureListener _fsgalleries_failure_listener;
	
	private DatabaseReference fbdbgalleries = _firebase.getReference("galleries");
	private ChildEventListener _fbdbgalleries_child_listener;
	private TimerTask tmr;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.gallerypreview);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		main = findViewById(R.id.main);
		boxHeader = findViewById(R.id.boxHeader);
		boxdetails = findViewById(R.id.boxdetails);
		image = findViewById(R.id.image);
		linear2 = findViewById(R.id.linear2);
		btnBack = findViewById(R.id.btnBack);
		textview1 = findViewById(R.id.textview1);
		BtnInformation = findViewById(R.id.BtnInformation);
		imageview2 = findViewById(R.id.imageview2);
		imageview4 = findViewById(R.id.imageview4);
		textview2 = findViewById(R.id.textview2);
		name = findViewById(R.id.name);
		textview4 = findViewById(R.id.textview4);
		timestamp = findViewById(R.id.timestamp);
		btnDelete = findViewById(R.id.btnDelete);
		imageview5 = findViewById(R.id.imageview5);
		textview6 = findViewById(R.id.textview6);
		d = new AlertDialog.Builder(this);
		
		btnBack.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		BtnInformation.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				showDetails = showDetails ? false : true;
				image.setVisibility(View.GONE);
				boxdetails.setVisibility(View.GONE);
				if (showDetails) {
					boxdetails.setVisibility(View.VISIBLE);
				}
				else {
					image.setVisibility(View.VISIBLE);
				}
			}
		});
		
		btnDelete.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				d.setTitle("Delete");
				d.setMessage("Do you want to delete this image from your gallery?");
				d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						pd.setTitle("Deleting");
						pd.setMessage("Please wait...");
						pd.setCancelable(false);
						pd.show();
						fbdbgalleries.child(f_id).removeValue();
						_firebase_storage.getReferenceFromUrl(f_url).delete().addOnSuccessListener(_fsgalleries_delete_success_listener).addOnFailureListener(_fsgalleries_failure_listener);
						tmr = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										finish();
									}
								});
							}
						};
						_timer.schedule(tmr, (int)(5000));
					}
				});
				d.setNegativeButton("No", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						
					}
				});
				d.create().show();
			}
		});
		
		_fsgalleries_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fsgalleries_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fsgalleries_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				
			}
		};
		
		_fsgalleries_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_fsgalleries_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_fsgalleries_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_fbdbgalleries_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		fbdbgalleries.addChildEventListener(_fbdbgalleries_child_listener);
	}
	
	private void initializeLogic() {
		_design();
		pd = new ProgressDialog(GallerypreviewActivity.this);
		showDetails = false;
		image.setVisibility(View.VISIBLE);
		boxdetails.setVisibility(View.GONE);
		dataMap = new Gson().fromJson(getIntent().getStringExtra("data"), new TypeToken<HashMap<String, Object>>(){}.getType());
		name.setText(dataMap.get("file_name").toString());
		timestamp.setText(dataMap.get("timestamp").toString());
		Glide.with(getApplicationContext()).load(Uri.parse(dataMap.get("file_url").toString())).into(image);
		f_id = dataMap.get("f_id").toString();
		f_url = dataMap.get("file_url").toString();
	}
	
	public void _design() {
		AJCode.setRoundedRipple(btnDelete,100,100,100,100,0xFFE57373,0,Color.TRANSPARENT,0xFFFFCDD2);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}