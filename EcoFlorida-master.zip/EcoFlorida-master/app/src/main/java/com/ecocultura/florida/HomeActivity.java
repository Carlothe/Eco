package com.ecocultura.florida;

import android.Manifest;
import android.animation.*;
import android.annotation.SuppressLint;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Build;
import android.provider.MediaStore;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import java.io.*;
import java.io.File;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import com.google.firebase.database.Query;


public class HomeActivity extends AppCompatActivity {
	
	public final int REQ_CD_CAMERA = 101;
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private DatabaseReference database;
	private Query query;
	private DatabaseReference placesRef;
	private DatabaseReference userFavorites;
	private boolean IsFavorite = false;
	private HashMap<String, Object> favoriteMap = new HashMap<>();
	private String favoriteId = "";
	private String userid = "";
	
	private ArrayList<HashMap<String, Object>> lmheritage = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lmtourismsite = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lmfavorites = new ArrayList<>();
	
	private LinearLayout linear7;
	private LinearLayout linear8;
	private ScrollView vscroll1;
	private LinearLayout main;
	private CardView boxHeader;
	private ImageView imageview5;
	private LinearLayout BoxHeritage;
	private LinearLayout BoxTourism;
	private LinearLayout linear2;
	private ImageView imageview4;
	private LinearLayout linear6;
	private LinearLayout linear3;
	private LinearLayout BtnFavorites;
	private LinearLayout BtnUser;
	private ImageView imageview2;
	private ImageView imageview3;
	private TextView textview3;
	private LinearLayout BoxHeritageLoading;
	private LinearLayout BoxHeritageEmpty;
	private RecyclerView rvheritage;
	private ProgressBar progressbar1;
	private TextView textview4;
	private TextView textview5;
	private LinearLayout BoxTourismLoading;
	private LinearLayout BoxTourismEmpty;
	private RecyclerView rvtourism;
	private ProgressBar progressbar2;
	private TextView textview6;
	private LinearLayout btnCam;
	private LinearLayout btnGallery;
	private ImageView imageview6;
	private ImageView imageview7;
	private TextView textview8;
	
	private DatabaseReference db = _firebase.getReference("places");
	private ChildEventListener _db_child_listener;
	private Intent i = new Intent();
	private DatabaseReference dbfavorites = _firebase.getReference("favorites");
	private ChildEventListener _dbfavorites_child_listener;
	private FirebaseAuth fbauth;
	private OnCompleteListener<AuthResult> _fbauth_create_user_listener;
	private OnCompleteListener<AuthResult> _fbauth_sign_in_listener;
	private OnCompleteListener<Void> _fbauth_reset_password_listener;
	private OnCompleteListener<Void> fbauth_updateEmailListener;
	private OnCompleteListener<Void> fbauth_updatePasswordListener;
	private OnCompleteListener<Void> fbauth_emailVerificationSentListener;
	private OnCompleteListener<Void> fbauth_deleteUserListener;
	private OnCompleteListener<Void> fbauth_updateProfileListener;
	private OnCompleteListener<AuthResult> fbauth_phoneAuthListener;
	private OnCompleteListener<AuthResult> fbauth_googleSignInListener;
	
	private TimerTask tmr;
	private Intent camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
	private File _file_camera;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear7 = findViewById(R.id.linear7);
		linear8 = findViewById(R.id.linear8);
		vscroll1 = findViewById(R.id.vscroll1);
		main = findViewById(R.id.main);
		boxHeader = findViewById(R.id.boxHeader);
		imageview5 = findViewById(R.id.imageview5);
		BoxHeritage = findViewById(R.id.BoxHeritage);
		BoxTourism = findViewById(R.id.BoxTourism);
		linear2 = findViewById(R.id.linear2);
		imageview4 = findViewById(R.id.imageview4);
		linear6 = findViewById(R.id.linear6);
		linear3 = findViewById(R.id.linear3);
		BtnFavorites = findViewById(R.id.BtnFavorites);
		BtnUser = findViewById(R.id.BtnUser);
		imageview2 = findViewById(R.id.imageview2);
		imageview3 = findViewById(R.id.imageview3);
		textview3 = findViewById(R.id.textview3);
		BoxHeritageLoading = findViewById(R.id.BoxHeritageLoading);
		BoxHeritageEmpty = findViewById(R.id.BoxHeritageEmpty);
		rvheritage = findViewById(R.id.rvheritage);
		progressbar1 = findViewById(R.id.progressbar1);
		textview4 = findViewById(R.id.textview4);
		textview5 = findViewById(R.id.textview5);
		BoxTourismLoading = findViewById(R.id.BoxTourismLoading);
		BoxTourismEmpty = findViewById(R.id.BoxTourismEmpty);
		rvtourism = findViewById(R.id.rvtourism);
		progressbar2 = findViewById(R.id.progressbar2);
		textview6 = findViewById(R.id.textview6);
		btnCam = findViewById(R.id.btnCam);
		btnGallery = findViewById(R.id.btnGallery);
		imageview6 = findViewById(R.id.imageview6);
		imageview7 = findViewById(R.id.imageview7);
		textview8 = findViewById(R.id.textview8);
		fbauth = FirebaseAuth.getInstance();
		_file_camera = FileUtil.createNewPictureFile(getApplicationContext());
		Uri _uri_camera;
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {

			_uri_camera = FileProvider.getUriForFile(this, "com.ecocultura.florida.provider", _file_camera);
		} else {
			_uri_camera = Uri.fromFile(_file_camera);
		}
		camera.putExtra(MediaStore.EXTRA_OUTPUT, _uri_camera);
		camera.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
		
		BtnFavorites.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				MainActivity.i.setClass(getApplicationContext(), FavoritesActivity.class);
				startActivity(MainActivity.i);
			}
		});
		
		BtnUser.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				MainActivity.i.setClass(getApplicationContext(), ProfileActivity.class);
				startActivity(MainActivity.i);
			}
		});
		
		btnCam.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(camera, REQ_CD_CAMERA);
			}
		});
		
		btnGallery.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), GalleryActivity.class);
				startActivity(i);
			}
		});
		
		_db_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		db.addChildEventListener(_db_child_listener);
		
		_dbfavorites_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		dbfavorites.addChildEventListener(_dbfavorites_child_listener);
		
		fbauth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fbauth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fbauth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fbauth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fbauth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		fbauth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fbauth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_fbauth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fbauth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fbauth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {

		userid = FirebaseAuth.getInstance().getCurrentUser().getUid();
		_LoadUserFavorites();

		tmr = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						_LoadHeritagePlaces();
						_LoadTourismSitePlaces();
					}
				});
			}
		};

		_timer.schedule(tmr, (int)(500));
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_CAMERA:
			if (_resultCode == Activity.RESULT_OK) {
				 String _filePath = _file_camera.getAbsolutePath();
				
				i.putExtra("image", _filePath);
				i.setClass(getApplicationContext(), CapturedpreviewActivity.class);
				startActivity(i);
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	public void _LoadPlaces(final String _category) {
		database = FirebaseDatabase.getInstance().getReference();
		DatabaseReference placesRef = database.child("places");
		placesRef.orderByChild("category")
		.equalTo(_category).addListenerForSingleValueEvent(new ValueEventListener() {
			 @Override
			public void onDataChange(DataSnapshot dataSnapShot) {
				lmheritage.clear();
				lmtourismsite.clear();
				for (DataSnapshot placeSnapshot : dataSnapShot.getChildren()) {
					if (_category.equals("Heritage")) {
						HashMap<String, Object> placeData = (HashMap<String, Object>) placeSnapshot.getValue();
						lmheritage.add(placeData);
					}
					if (_category.equals("Tourism Site")) {
						HashMap<String, Object> placeData = (HashMap<String, Object>) placeSnapshot.getValue();
						lmtourismsite.add(placeData);
					}
				}
				_LoadRvs();
			}
			@Override
			public void onCancelled(DatabaseError databaseError) {
				SketchwareUtil.showMessage(getApplicationContext(), databaseError.getMessage());
			}
			 });
	}
	
	
	public void _LoadRvs() {
		BoxHeritageLoading.setVisibility(View.GONE);
		BoxHeritageEmpty.setVisibility(View.GONE);
		rvheritage.setVisibility(View.GONE);
		if (lmheritage.size() == 0) {
			BoxHeritageEmpty.setVisibility(View.VISIBLE);
		}
		else {
			rvheritage.setVisibility(View.VISIBLE);
			rvheritage.setAdapter(new RvheritageAdapter(lmheritage));
			rvheritage.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		}
		BoxTourismLoading.setVisibility(View.GONE);
		BoxTourismEmpty.setVisibility(View.GONE);
		rvtourism.setVisibility(View.GONE);
		if (lmtourismsite.size() == 0) {
			BoxTourismEmpty.setVisibility(View.VISIBLE);
		}
		else {
			rvtourism.setVisibility(View.VISIBLE);
			rvtourism.setAdapter(new RvtourismAdapter(lmtourismsite));
			rvtourism.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		}
	}
	
	
	public void _LoadHeritagePlaces() {
		database = FirebaseDatabase.getInstance().getReference();
		DatabaseReference placesRef = database.child("places");
		placesRef.orderByChild("category")
		.equalTo("Cultural Sites").addListenerForSingleValueEvent(new ValueEventListener() {
			 @Override
			public void onDataChange(DataSnapshot dataSnapShot) {
				lmheritage.clear();
				for (DataSnapshot placeSnapshot : dataSnapShot.getChildren()) {
					HashMap<String, Object> placeData = (HashMap<String, Object>) placeSnapshot.getValue();
					lmheritage.add(placeData);
				}
				_LoadRvs();
			}
			@Override
			public void onCancelled(DatabaseError databaseError) {
				SketchwareUtil.showMessage(getApplicationContext(), databaseError.getMessage());
			}
			 });
	}
	
	
	public void _LoadTourismSitePlaces() {
		database = FirebaseDatabase.getInstance().getReference();
		DatabaseReference EcoTourismRef = database.child("places");
		EcoTourismRef.orderByChild("category")
		.equalTo("Ecological Sites").addListenerForSingleValueEvent(new ValueEventListener() {
			 @Override
			public void onDataChange(DataSnapshot dataSnapShot) {
				lmtourismsite.clear();
				for (DataSnapshot placeSnapshot : dataSnapShot.getChildren()) {
					HashMap<String, Object> placeData = (HashMap<String, Object>) placeSnapshot.getValue();
					lmtourismsite.add(placeData);
				}
				_LoadRvs();
			}
			@Override
			public void onCancelled(DatabaseError databaseError) {
				SketchwareUtil.showMessage(getApplicationContext(), databaseError.getMessage());
			}
			 });
	}
	
	
	public void _LoadUserFavorites() {
		database = FirebaseDatabase.getInstance().getReference();
		DatabaseReference userFavorites = database.child("favorites");
		userFavorites.orderByChild("userid")
		.equalTo(userid).addListenerForSingleValueEvent(new ValueEventListener() {
			 @Override
			public void onDataChange(DataSnapshot dataSnapShot) {
				lmfavorites.clear();
				for (DataSnapshot favoriteSnapshot : dataSnapShot.getChildren()) {
					HashMap<String, Object> favoriteData = (HashMap<String, Object>) favoriteSnapshot.getValue();
					lmfavorites.add(favoriteData);
				}
				MainActivity.sp.edit().putString("userFavorites", new Gson().toJson(lmfavorites)).commit();
			}
			@Override
			public void onCancelled(DatabaseError databaseError) {
				SketchwareUtil.showMessage(getApplicationContext(), databaseError.getMessage());
			}
			 });
	}
	
	
	public boolean _CheckIfAlreadyFavorite(final String _place_id) {
		for(int _repeat12 = 0; _repeat12 < (int)(lmfavorites.size()); _repeat12++) {
			if (lmfavorites.get((int)_repeat12).get("place_id").toString().equals(_place_id)) {
				return (true);
			}
		}
		return (false);
	}
	
	
	public void _ToggleFavorite(final String _place_id, final HashMap<String, Object> _favorite_map) {
		if (_CheckIfAlreadyFavorite(_place_id)) {
			dbfavorites.child(_GetFavoriteId(_place_id)).removeValue();
		}
		else {
			favoriteId = dbfavorites.push().getKey();
			favoriteMap = new HashMap<>();
			favoriteMap.put("id", favoriteId);
			favoriteMap.put("place_id", _place_id);
			favoriteMap.put("userid", userid);
			favoriteMap.put("name", _favorite_map.get("name").toString());
			favoriteMap.put("thumbnail", _favorite_map.get("thumbnail").toString());
			favoriteMap.put("category", _favorite_map.get("category").toString());
			favoriteMap.put("address", _favorite_map.get("address").toString());
			dbfavorites.child(favoriteId).updateChildren(favoriteMap);
		}
		_LoadUserFavorites();
	}
	
	
	public String _GetFavoriteId(final String _place_id) {
		for(int _repeat12 = 0; _repeat12 < (int)(lmfavorites.size()); _repeat12++) {
			if (lmfavorites.get((int)_repeat12).get("place_id").toString().equals(_place_id)) {
				return (lmfavorites.get((int)_repeat12).get("id").toString());
			}
		}
		return ("");
	}
	
	public class RvheritageAdapter extends RecyclerView.Adapter<RvheritageAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public RvheritageAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.cvslideshow, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}

		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;

			final LinearLayout BoxSlideshowItem = _view.findViewById(R.id.BoxSlideshowItem);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final TextView name = _view.findViewById(R.id.name);
			final ImageView thumbnail = _view.findViewById(R.id.thumbnail);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout BtnAddToFavorites = _view.findViewById(R.id.BtnAddToFavorites);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);

			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_view.setLayoutParams(_lp);
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("thumbnail").toString())).into(thumbnail);
			name.setText(_data.get((int)_position).get("name").toString());
			AJCode.setRoundedRipple(BtnAddToFavorites,50,50,50,50,0xFFFEFAF6,0,Color.TRANSPARENT,0xFF3A5245);
			// Favorite
			if (_CheckIfAlreadyFavorite(_data.get((int)_position).get("id").toString())) {
				imageview2.setImageResource(R.drawable.heartfilled);
			}
			else {
				imageview2.setImageResource(R.drawable.heart);
			}
			BtnAddToFavorites.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (_CheckIfAlreadyFavorite(_data.get((int)_position).get("id").toString())) {
						imageview2.setImageResource(R.drawable.heart);
					}
					else {
						imageview2.setImageResource(R.drawable.heartfilled);
					}
					_ToggleFavorite(_data.get((int)_position).get("id").toString(), _data.get((int)(_position)));
				}
			});
			BoxSlideshowItem.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.putExtra("id", _data.get((int)_position).get("id").toString());
					i.putExtra("data", new Gson().toJson(_data.get((int)(_position))));
					i.setClass(getApplicationContext(), PlacedetailsActivity.class);
					startActivity(i);
				}
			});
		}

		@Override
		public int getItemCount() {
			return _data.size();
		}

		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class RvtourismAdapter extends RecyclerView.Adapter<RvtourismAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public RvtourismAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.cvslideshow, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, @SuppressLint("RecyclerView") final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout BoxSlideshowItem = _view.findViewById(R.id.BoxSlideshowItem);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final TextView name = _view.findViewById(R.id.name);
			final ImageView thumbnail = _view.findViewById(R.id.thumbnail);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout BtnAddToFavorites = _view.findViewById(R.id.BtnAddToFavorites);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_view.setLayoutParams(_lp);
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("thumbnail").toString())).into(thumbnail);
			name.setText(_data.get((int)_position).get("name").toString());
			AJCode.setRoundedRipple(BtnAddToFavorites,50,50,50,50,0xFFFEFAF6,0,Color.TRANSPARENT,0xFF3A5245);
			if (_CheckIfAlreadyFavorite(_data.get((int)_position).get("id").toString())) {
				imageview2.setImageResource(R.drawable.heartfilled);
			}
			else {
				imageview2.setImageResource(R.drawable.heart);
			}
			BtnAddToFavorites.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (_CheckIfAlreadyFavorite(_data.get((int)_position).get("id").toString())) {
						imageview2.setImageResource(R.drawable.heart);
					}
					else {
						imageview2.setImageResource(R.drawable.heartfilled);
					}
					_ToggleFavorite(_data.get((int)_position).get("id").toString(), _data.get((int)(_position)));
				}
			});
			thumbnail.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.putExtra("id", _data.get((int)_position).get("id").toString());
					i.putExtra("data", new Gson().toJson(_data.get((int)(_position))));
					i.setClass(getApplicationContext(), PlacedetailsActivity.class);
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}

	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
