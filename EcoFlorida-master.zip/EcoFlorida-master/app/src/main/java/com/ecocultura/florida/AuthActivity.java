package com.ecocultura.florida;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.os.*;
import android.util.*;
import android.view.View;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;

import java.util.*;
import java.util.HashMap;


public class AuthActivity extends AppCompatActivity {
	
	public final int REQ_CD_GL = 101;
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private GoogleSignInOptions gop;
	private GoogleSignInAccount gsia;
	private String uid = "";
	private HashMap<String, Object> details = new HashMap<>();
	private HashMap<String, Object> account = new HashMap<>();
	
	private LinearLayout main;
	private ImageView imageview1;
	private LinearLayout BtnAuthenticate;
	private ProgressBar ProgressbarAuth;
	private TextView TextAuth;
	
	private FirebaseAuth fbauth;
	private OnCompleteListener<AuthResult> _fbauth_create_user_listener;
	private OnCompleteListener<AuthResult> _fbauth_sign_in_listener;
	private OnCompleteListener<Void> _fbauth_reset_password_listener;
	private OnCompleteListener<Void> fbauth_updateEmailListener;
	private OnCompleteListener<Void> fbauth_updatePasswordListener;
	private OnCompleteListener<Void> fbauth_emailVerificationSentListener;
	private OnCompleteListener<Void> fbauth_deleteUserListener;
	private OnCompleteListener<Void> fbauth_updateProfileListener;
	private OnCompleteListener<AuthResult> fbauth_phoneAuthListener;
	private OnCompleteListener<AuthResult> fbauth_googleSignInListener;
	
	private GoogleSignInClient gl;
	private DatabaseReference db = _firebase.getReference("account");
	private ChildEventListener _db_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.auth);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		main = findViewById(R.id.main);
		imageview1 = findViewById(R.id.imageview1);
		BtnAuthenticate = findViewById(R.id.BtnAuthenticate);
		ProgressbarAuth = findViewById(R.id.ProgressbarAuth);
		TextAuth = findViewById(R.id.TextAuth);
		fbauth = FirebaseAuth.getInstance();
		
		BtnAuthenticate.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				ProgressbarAuth.setVisibility(View.VISIBLE);
				TextAuth.setVisibility(View.GONE);
				BtnAuthenticate.setEnabled(false);
				Intent signInIntent = gl.getSignInIntent();
				startActivityForResult(signInIntent, REQ_CD_GL);
			}
		});
		
		_db_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if ((FirebaseAuth.getInstance().getCurrentUser() != null)) {
					if (FirebaseAuth.getInstance().getCurrentUser().getUid().equals(_childKey)) {
						if (_childValue.get("type").toString().equals("admin")) {
							MainActivity.i.setClass(getApplicationContext(), DashboardActivity.class);
							startActivity(MainActivity.i);
						}
						else {
							MainActivity.i.setClass(getApplicationContext(), HomeActivity.class);
							startActivity(MainActivity.i);
						}
						finish();
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
			}
		};
		db.addChildEventListener(_db_child_listener);
		
		fbauth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fbauth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fbauth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fbauth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fbauth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		fbauth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fbauth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_fbauth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fbauth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fbauth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		_design();
		GoogleSignInOptions gop = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestEmail().requestProfile().requestIdToken("774391823637-psnunibj15pkh51tu688taupbfoak0fp.apps.googleusercontent.com").build();
		gl = GoogleSignIn.getClient(this,gop);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		SketchwareUtil.showMessage(getApplicationContext(), String.valueOf(_resultCode));
		switch (_requestCode) {
			case REQ_CD_GL:
			if (_resultCode == Activity.RESULT_OK) {
				Task<GoogleSignInAccount> _task = GoogleSignIn.getSignedInAccountFromIntent(_data);
				try{
					gsia = _task.getResult(ApiException.class);
					AuthCredential credential = GoogleAuthProvider.getCredential(gsia.getIdToken(), null);
					fbauth.signInWithCredential(credential).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
						@Override
						public void onComplete(@NonNull Task<AuthResult> task) {
							uid = FirebaseAuth.getInstance().getCurrentUser().getUid();
							// Create Account
							db.addListenerForSingleValueEvent(new ValueEventListener() {
									@Override
									public void onDataChange(DataSnapshot _dataSnapshot) {
											if (_dataSnapshot.hasChild(uid)) {
										Map<String,Object> account = (Map<String,Object>) _dataSnapshot.child(uid).getValue();
										if (account.get("type").toString().equals("admin")) {
											MainActivity.i.setClass(getApplicationContext(), DashboardActivity.class);
											startActivity(MainActivity.i);
										}
										else {
											MainActivity.i.setClass(getApplicationContext(), HomeActivity.class);
											startActivity(MainActivity.i);
										}
										finish();
									}
									else {
										details = new HashMap<>();
										details.put("uid", uid);
										details.put("gid", gsia.getId());
										details.put("email", gsia.getEmail());
										details.put("name", gsia.getDisplayName());
										details.put("fname", gsia.getGivenName());
										details.put("lname", gsia.getFamilyName());
										details.put("type", "user");
										db.child(uid).updateChildren(details);
									}
									}
									@Override
									public void onCancelled(DatabaseError _databaseError) {
									}
							});
						}
					});
				} catch(ApiException e){
					String Error = e.getMessage();
					SketchwareUtil.showMessage(getApplicationContext(), "Failed sign-up or sign-in something went wrong with google service, please try again later or contact the administrator.");
					SketchwareUtil.showMessage(getApplicationContext(), Error);
					TextAuth.setVisibility(View.VISIBLE);
					ProgressbarAuth.setVisibility(View.GONE);
					BtnAuthenticate.setEnabled(true);
				}
			}
			else {
				TextAuth.setVisibility(View.VISIBLE);
				ProgressbarAuth.setVisibility(View.GONE);
				BtnAuthenticate.setEnabled(true);
			}
			break;
			default:
			break;
		}
	}
	
	public void _design() {
		AJCode.setRoundedRipple(BtnAuthenticate,5,5,5,5,0xFF4F6E4F,0,Color.TRANSPARENT,0xFFC8E6C9);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}
