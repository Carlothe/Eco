package com.ecocultura.florida;

import android.content.Intent;
import android.net.Uri;
import android.os.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.widget.*;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.bumptech.glide.Glide;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;

import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;

public class MgalleryActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private ArrayList<HashMap<String, Object>> lmGalleries = new ArrayList<>();
	
	private LinearLayout main;
	private CardView boxHeader;
	private ListView lv;
	private LinearLayout linear2;
	private LinearLayout btnBack;
	private TextView textview1;
	private ImageView imageview2;
	
	private DatabaseReference fbdbgalleries = _firebase.getReference("galleries");
	private ChildEventListener _fbdbgalleries_child_listener;
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.mgallery);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		main = findViewById(R.id.main);
		boxHeader = findViewById(R.id.boxHeader);
		lv = findViewById(R.id.lv);
		linear2 = findViewById(R.id.linear2);
		btnBack = findViewById(R.id.btnBack);
		textview1 = findViewById(R.id.textview1);
		imageview2 = findViewById(R.id.imageview2);
		
		btnBack.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		_fbdbgalleries_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		fbdbgalleries.addChildEventListener(_fbdbgalleries_child_listener);
	}
	
	private void initializeLogic() {
	}
	
	@Override
	public void onResume() {
		super.onResume();
		_loadgalleries();
	}
	public void _loadgalleries() {
		lmGalleries.clear();
		fbdbgalleries.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				lmGalleries = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						lmGalleries.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				lv.setAdapter(new LvAdapter(lmGalleries));
				((BaseAdapter)lv.getAdapter()).notifyDataSetChanged();
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
	}
	
	public class LvAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public LvAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.cvadmingallery, null);
			}
			
			final LinearLayout main = _view.findViewById(R.id.main);
			final androidx.cardview.widget.CardView card = _view.findViewById(R.id.card);
			final LinearLayout box = _view.findViewById(R.id.box);
			final androidx.cardview.widget.CardView cardview2 = _view.findViewById(R.id.cardview2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final ImageView image = _view.findViewById(R.id.image);
			final LinearLayout linear4 = _view.findViewById(R.id.linear4);
			final TextView textview3 = _view.findViewById(R.id.textview3);
			final TextView timestamp = _view.findViewById(R.id.timestamp);
			final de.hdodenhof.circleimageview.CircleImageView profile = _view.findViewById(R.id.profile);
			final LinearLayout linear5 = _view.findViewById(R.id.linear5);
			final TextView u_name = _view.findViewById(R.id.u_name);
			final TextView u_email = _view.findViewById(R.id.u_email);
			
			timestamp.setText(_data.get((int)_position).get("timestamp").toString());
			u_name.setText(_data.get((int)_position).get("u_name").toString());
			u_email.setText(_data.get((int)_position).get("u_email").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("u_profile").toString())).into(profile);
			try {
				Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("file_url").toString())).into(image);
			} catch (Exception e) {
				image.setImageResource(R.drawable.logo);
			}
			box.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.putExtra("data", new Gson().toJson(_data.get((int)(_position))));
					i.setClass(getApplicationContext(), GallerypreviewActivity.class);
					startActivity(i);
				}
			});
			
			return _view;
		}
	}

}
